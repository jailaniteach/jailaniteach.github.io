package com.nep.myfirstwebapp.studentmanagement.model;

import javax.persistence.*;

@Entity
@Table(name="pbstudents")
public class Student {
	
	@Column(unique=true, nullable=false)
	String sid;
	@Column(nullable=false, length=100)
	String name;
	@ManyToOne(cascade=CascadeType.REFRESH)
	@JoinColumn()
	Group groupPb;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int generatedId;
	
	public Student() {}
	
	public Student(String sid, String name, Group groupPb) {
		this.sid = sid;
		this.name = name;
		this.groupPb = groupPb;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Group getGroupPb() {
		return groupPb;
	}

	public void setGroupPb(Group groupPb) {
		this.groupPb = groupPb;
	}

	public String getSid() {
		return sid;
	}
	
	public int getGeneratedId() {
		return generatedId;
	}

}
