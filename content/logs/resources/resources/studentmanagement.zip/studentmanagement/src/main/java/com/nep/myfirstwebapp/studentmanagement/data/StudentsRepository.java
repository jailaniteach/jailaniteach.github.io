package com.nep.myfirstwebapp.studentmanagement.data;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.nep.myfirstwebapp.studentmanagement.model.Group;
import com.nep.myfirstwebapp.studentmanagement.model.Student;

@Component
public class StudentsRepository {

	ArrayList<Student> ALL_STUDENTS = new ArrayList<Student>();
	
	public StudentsRepository() {		
		ALL_STUDENTS.add(new Student("21FTT1101", "Abu", new Group("DITN12", "IT Network")));
		ALL_STUDENTS.add(new Student("21FTT1102", "Bakar", new Group("DITN12", "IT Network")));
		ALL_STUDENTS.add(new Student("21FTT1103", "Curi", new Group("DITN10", "Info Sys")));
		ALL_STUDENTS.add(new Student("21FTT1104", "Daging", new Group("DISS07", "Info Sys")));
		ALL_STUDENTS.add(new Student("21FTT1105", "Emak", new Group("DISS07", "Info Sys")));
	}
	
	public List<Student> getAllStudents() {
		return ALL_STUDENTS;
	}
	
	public Student findStudent(String id) {
		for(Student student : ALL_STUDENTS) {
			if(student.getSid().equalsIgnoreCase(id)) {
				return student;
			}
		}
		return null;
	}
	
}
