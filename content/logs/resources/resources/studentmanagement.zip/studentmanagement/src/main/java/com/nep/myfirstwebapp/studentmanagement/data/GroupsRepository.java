package com.nep.myfirstwebapp.studentmanagement.data;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

import com.nep.myfirstwebapp.studentmanagement.model.Group;

@Component
public class GroupsRepository {
	
	List<Group> ALL_GROUPS = Arrays.asList(
			new Group("DITN12", "IT Network"),
			new Group("DISS07", "Info Sys")
			);

	public List<Group> getAllGroups() {
		return ALL_GROUPS;
	}
	
	public Group findGroup(String groupCode) {
		for(Group group : ALL_GROUPS) {
			if(group.getGroupCode().equalsIgnoreCase(groupCode)) {
				return group;
			}
		}
		return null;
	}
	
}
