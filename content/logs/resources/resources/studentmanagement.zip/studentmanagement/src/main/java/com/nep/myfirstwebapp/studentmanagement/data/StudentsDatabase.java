package com.nep.myfirstwebapp.studentmanagement.data;

import javax.transaction.Transactional;

import org.springframework.data.repository.CrudRepository;

import com.nep.myfirstwebapp.studentmanagement.model.Student;

@Transactional
public interface StudentsDatabase extends CrudRepository<Student, Integer> {

	public Student findBySidIgnoreCase(String sid);
	
}
