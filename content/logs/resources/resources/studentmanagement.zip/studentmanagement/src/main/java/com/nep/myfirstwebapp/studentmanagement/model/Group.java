package com.nep.myfirstwebapp.studentmanagement.model;

import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name="pbgroups")
public class Group {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int id;
	@Column(nullable=false, unique=true)
	String groupCode;
	@Column(nullable=false)
	String programme;
	@OneToMany(
			fetch=FetchType.LAZY,
			mappedBy="groupPb",
			cascade=CascadeType.ALL
			)
	Set<Student> students;
	
	public Group() {}
	
	public Group(String groupCode, String programme) {
		this.groupCode = groupCode;
		this.programme = programme;
	}

	public String getGroupCode() {
		return groupCode;
	}

	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}

	public String getProgramme() {
		return programme;
	}

	public void setProgramme(String programme) {
		this.programme = programme;
	}
	
	public int getId() {
		return id;
	}
	
	public void setStudents(Set<Student> students) {
		this.students = students;
	}
	
	public Set<Student> getStudents() {
		return students;
	}
	
}
