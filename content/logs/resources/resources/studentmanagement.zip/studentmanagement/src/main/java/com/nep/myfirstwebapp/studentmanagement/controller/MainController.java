package com.nep.myfirstwebapp.studentmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nep.myfirstwebapp.studentmanagement.data.GroupsDatabase;
import com.nep.myfirstwebapp.studentmanagement.data.GroupsRepository;
import com.nep.myfirstwebapp.studentmanagement.data.StudentsDatabase;
import com.nep.myfirstwebapp.studentmanagement.data.StudentsRepository;
import com.nep.myfirstwebapp.studentmanagement.model.Group;
import com.nep.myfirstwebapp.studentmanagement.model.Student;

@Controller
public class MainController {
	
	@Autowired
	StudentsRepository studentsRepo;
	@Autowired
	GroupsRepository groupsRepo;
	@Autowired
	StudentsDatabase studentsData;
	@Autowired
	GroupsDatabase groupsData;

	@RequestMapping(value = "/")
	public String home(ModelMap modelMap) {
//		Group group = new Group("DITN12", "IT Network");
//		Student student = new Student(
//				"21FTT1000", "Abu", group);
//		modelMap.put("student", student);
//		List<Student> allStudents = studentsRepo.getAllStudents();
		List<Student> allStudents =
				(List<Student>) studentsData.findAll();
		modelMap.put("allStudents", allStudents);
		return "students";
	}
	
	@RequestMapping(value = "/addstudent")
	public String addStudent(ModelMap modelMap) {
//		List<Group> allGroups = groupsRepo.getAllGroups();
		List<Group> allGroups = 
				(List<Group>) groupsData.findAll();
		modelMap.put("allGroups", allGroups);
		return "add_student";
	}
	
	@RequestMapping(value = "/add/student")
	public String addingStudent(
			@RequestParam(required=true) String student_id,
			@RequestParam(required=true) String full_name,
			@RequestParam(required=true) String group_code
			) {
//		Group group = groupsRepo.findGroup(group_code);
		Group group = groupsData.findByGroupCode(group_code);
		Student student = new Student(student_id, full_name, group);
//		studentsRepo.getAllStudents().add(student);
		studentsData.save(student);
		return "redirect:/";
	}
	
	@RequestMapping(value = "/editstudent/{sId}")
	public String editStudent(
			@PathVariable String sId,
			ModelMap modelMap
			) {
//		Student student = studentsRepo.findStudent(sId);
		Student student = studentsData.findBySidIgnoreCase(sId);
		if(student != null) {
			modelMap.put("student", student);
			
//			List<Group> allGroups = groupsRepo.getAllGroups();
			List<Group> allGroups = 
					(List<Group>) groupsData.findAll();
			modelMap.put("allGroups", allGroups);
			return "edit_student";
		} else {
			return "redirect:/";
		}
	}
	
	@RequestMapping(value = "/edit/student/{sId}")
	public String editingStudent(
			@PathVariable String sId,
			@RequestParam(required=true) String full_name,
			@RequestParam(required=true) String group_code,
			ModelMap modelMap
			) {
//		Student student = studentsRepo.findStudent(sId);
		Student student = studentsData.findBySidIgnoreCase(sId);
		if(student != null) {
			student.setName(full_name);
//			Group group = groupsRepo.findGroup(group_code);
			Group group = groupsData.findByGroupCode(group_code);
			if(group != null) {
				student.setGroupPb(group);				
			}
			studentsData.save(student);
//			modelMap.put("student", student);
//			
//			List<Group> allGroups = groupsRepo.getAllGroups();
//			modelMap.put("allGroups", allGroups);
//			return "edit_student";
			return "redirect:/editstudent/" + sId;
		} else {
			return "redirect:/";
		}
	}
	
	@RequestMapping(value = "/deletestudent/{sId}")
	public String deleteStudent(
			@PathVariable String sId
			) {
		Student student = studentsData.findBySidIgnoreCase(sId);
		if(student != null) {			
//			studentsData.deleteById(student.getGeneratedId());
			// or
			studentsData.delete(student);
		}
		return "redirect:/";
	}
	
	@RequestMapping(value = "/groups")
	public String groups(ModelMap modelMap) {
		List<Group> allGroups = groupsRepo.getAllGroups();
		modelMap.put("allGroups", allGroups);
		return "groups";
	}
	
	@RequestMapping(value = "/editgroup")
	public String editGroup() {
		return "edit_group";
	}
	
	@RequestMapping(value = "/contactus")
	public String contactus(ModelMap modelMap) {
		modelMap.put("org_name", "NS4307 Sdn. Bhd.");
		modelMap.put("org_address", 
				"Block 2E, Ong Sum Ping, Politeknik Brunei.");
		modelMap.put("org_phone", 8888888);
		return "contact_us";
	}
}
