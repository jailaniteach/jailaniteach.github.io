package com.nep.myfirstwebapp.studentmanagement.data;

import javax.transaction.Transactional;

import org.springframework.data.repository.CrudRepository;

import com.nep.myfirstwebapp.studentmanagement.model.Group;

@Transactional
public interface GroupsDatabase extends CrudRepository<Group, Integer> {

	public Group findByGroupCode(String groupCode);
	
}
